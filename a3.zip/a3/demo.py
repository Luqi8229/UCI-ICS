#Luqi Chen
#luqic2@uci.edu
#69278864

import ds_client

if __name__ == "__main__":
    ds_client.send("168.235.86.101", 3021, "lil123", "doomed123", "Goodbye World", "doomed")
